
```php
<?php
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject']; // New field for subject
    $message = $_POST['message'];
    
    $to = 'leackyotieno4@gmail.com'; // Replace with your Gmail address
    $email_subject = 'New form submission: ' . $subject;
    $body = "Name: $name\nEmail: $email\nSubject: $subject\n\n$message";
    
    if(mail($to, $email_subject, $body)){
        echo 'Thank you for your message! We will get back to you soon.';
    } else{
        echo 'Sorry, there was an error sending your message. Please try again later.';
    }
}
?>
```